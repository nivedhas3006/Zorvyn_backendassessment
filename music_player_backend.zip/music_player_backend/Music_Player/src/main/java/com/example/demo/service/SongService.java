package com.example.demo.service;

import java.util.List;

import com.example.demo.bean.Song;
import com.example.demo.repo.SongRepo;

public class SongService {
    private SongRepo repo;

    public SongService() {
        repo = new SongRepo();
    }

    public void saveSong(Song obj) {
        repo.saveSong(obj);
    }

    public List<Song> getAllSongs() {
        return repo.getAllSongs();
    }

    public void updateSong(Song obj) {
        repo.updateSong(obj);
    }

    public void deleteSong(int songid) {
        repo.deleteSong(songid);
    }

    public Song getSong(int songid) {
        return repo.getSong(songid);
    }

    public List<Song> searchSongs(String keyword, String genre, String mood, String lyrics) {
        if (keyword != null && !keyword.isEmpty()) {
            return repo.searchSongs("title", keyword);
        }
        if (genre != null && !genre.isEmpty()) {
            return repo.searchSongs("genre", genre);
        }
        if (mood != null && !mood.isEmpty()) {
            return repo.searchSongs("mood", mood);
        }
        if (lyrics != null && !lyrics.isEmpty()) {
            return repo.searchSongs("lyrics", lyrics);
        }
        return repo.getAllSongs();
    }
}

