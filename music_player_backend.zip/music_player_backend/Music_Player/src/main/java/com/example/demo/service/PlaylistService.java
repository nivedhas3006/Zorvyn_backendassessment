package com.example.demo.service;

import java.util.List;

import com.example.demo.bean.Playlist;
import com.example.demo.bean.Song;
import com.example.demo.repo.PlaylistRepo;

public class PlaylistService {
    private PlaylistRepo repo;

    public PlaylistService() {
        repo = new PlaylistRepo();
    }

    public void savePlaylist(Playlist obj) {
        repo.savePlaylist(obj);
    }

    public List<Playlist> getAllPlaylists() {
        return repo.getAllPlaylists();
    }

    public void updatePlaylist(Playlist obj) {
        repo.updatePlaylist(obj);
    }

    public void deletePlaylist(int id) {
        repo.deletePlaylist(id);
    }

    public Playlist getPlaylist(int id) {
        return repo.getPlaylist(id);
    }

    public void addSongToPlaylist(int playlistId, int songId) {
        repo.addSongToPlaylist(playlistId, songId);
    }

    public List<Song> getSongsByPlaylist(int playlistId) {
        return repo.getSongsByPlaylist(playlistId);
    }
    public void removeSongFromPlaylist(int playlistId, int songId) {
        repo.removeSongFromPlaylist(playlistId, songId);
    }

}
