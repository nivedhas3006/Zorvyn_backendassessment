package com.example.demo.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;

import com.example.demo.controller.ArtistController;
import com.example.demo.controller.FavoritesController;
import com.example.demo.controller.PlaylistController;
import com.example.demo.controller.SongController;
import com.example.demo.controller.UserController;

@Configuration
public class Config extends ResourceConfig {
    public Config() {
        register(SongController.class);
        register(PlaylistController.class);
        register(UserController.class);
        register(ArtistController.class);
        register(FavoritesController.class);
    }

    public static Connection getConnectionFormsql() {
        Connection con = null;
        try {
            // Load MySQL driver (Connector/J 5.x)
            com.mysql.jdbc.Driver d = new com.mysql.jdbc.Driver();
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/musicdb",
                "root",
                "Harshitha_11"
            );
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }
}
