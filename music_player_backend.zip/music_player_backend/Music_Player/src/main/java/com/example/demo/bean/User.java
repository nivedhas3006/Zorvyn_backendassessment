package com.example.demo.bean;

public class User {
private int userid;
private String username;
private String useremail;
private boolean isPremimum;
public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getUseremail() {
	return useremail;
}
public void setUseremail(String useremail) {
	this.useremail = useremail;
}
public boolean isPremimum() {
	return isPremimum;
}
public void setPremimum(boolean isPremimum) {
	this.isPremimum = isPremimum;
}


}
