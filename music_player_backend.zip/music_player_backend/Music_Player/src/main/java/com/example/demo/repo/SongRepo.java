package com.example.demo.repo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.bean.Song;
import com.example.demo.config.Config;

public class SongRepo {

    // Save song
    public void saveSong(Song song) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO song(title, artist, genre, mood, lyrics) VALUES(?,?,?,?,?)");
            ps.setString(1, song.getTitle());
            ps.setString(2, song.getArtist());
            ps.setString(3, song.getGenre());
            ps.setString(4, song.getMood());
            ps.setString(5, song.getLyrics());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update song
    public void updateSong(Song obj) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE song SET title=?, artist=?, genre=?, mood=?, lyrics=? WHERE songid=?");
            ps.setString(1, obj.getTitle());
            ps.setString(2, obj.getArtist());
            ps.setString(3, obj.getGenre());
            ps.setString(4, obj.getMood());
            ps.setString(5, obj.getLyrics());
            ps.setInt(6, obj.getSongid());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete song
    public void deleteSong(int songid) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement("DELETE FROM song WHERE songid=?");
            ps.setInt(1, songid);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get all songs
    public List<Song> getAllSongs() {
        List<Song> list = new ArrayList<>();
        try (Connection con = Config.getConnectionFormsql();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM song")) {
            while (rs.next()) {
                Song s = new Song();
                s.setSongid(rs.getInt("songid"));
                s.setTitle(rs.getString("title"));
                s.setArtist(rs.getString("artist"));
                s.setGenre(rs.getString("genre"));
                s.setMood(rs.getString("mood"));
                s.setLyrics(rs.getString("lyrics"));
                list.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // ✅ Get single song by id
    public Song getSong(int songid) {
        Song s = null;
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM song WHERE songid=?");
            ps.setInt(1, songid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                s = new Song();
                s.setSongid(rs.getInt("songid"));
                s.setTitle(rs.getString("title"));
                s.setArtist(rs.getString("artist"));
                s.setGenre(rs.getString("genre"));
                s.setMood(rs.getString("mood"));
                s.setLyrics(rs.getString("lyrics"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return s;
    }

    // Search by attribute
    public List<Song> searchSongs(String column, String keyword) {
        List<Song> list = new ArrayList<>();
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM song WHERE " + column + " LIKE ?");
            ps.setString(1, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Song s = new Song();
                s.setSongid(rs.getInt("songid"));
                s.setTitle(rs.getString("title"));
                s.setArtist(rs.getString("artist"));
                s.setGenre(rs.getString("genre"));
                s.setMood(rs.getString("mood"));
                s.setLyrics(rs.getString("lyrics"));
                list.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
