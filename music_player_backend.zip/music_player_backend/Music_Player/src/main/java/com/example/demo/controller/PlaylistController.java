package com.example.demo.controller;

import java.util.List;

import com.example.demo.bean.Playlist;
import com.example.demo.bean.Song;
import com.example.demo.service.PlaylistService;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.MediaType;

@Path("/dbplaylist")
public class PlaylistController {
    private PlaylistService service;

    public PlaylistController() {
        service = new PlaylistService();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String savePlaylist(Playlist obj) {
        service.savePlaylist(obj);
        return "Playlist has been saved";
    }

    @GET
    public List<Playlist> getAllPlaylists() {
        return service.getAllPlaylists();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public String updatePlaylist(Playlist obj) {
        service.updatePlaylist(obj);
        return "Playlist has been updated";
    }

    @DELETE
    @Path("/{id}")
    public String deletePlaylist(@PathParam("id") int id) {
        service.deletePlaylist(id);
        return "Playlist has been removed";
    }

    @POST
    @Path("/{playlistId}/songs/{songId}")
    public String addSongToPlaylist(@PathParam("playlistId") int playlistId,
                                    @PathParam("songId") int songId) {
        service.addSongToPlaylist(playlistId, songId);
        return "Song added to playlist";
    }

    @GET
    @Path("/{playlistId}/songs")
    public List<Song> getSongsByPlaylist(@PathParam("playlistId") int playlistId) {
        return service.getSongsByPlaylist(playlistId);
    }
    
    @DELETE
    @Path("/{playlistId}/songs/{songId}")
    public String removeSongFromPlaylist(@PathParam("playlistId") int playlistId,
                                         @PathParam("songId") int songId) {
        service.removeSongFromPlaylist(playlistId, songId);
        return "Song removed from playlist";
    }

}
