
package com.example.demo.controller;

import java.util.List;

import com.example.demo.bean.Song;
import com.example.demo.service.SongService;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/dbsong")
public class SongController {
    private SongService service;

    public SongController() {
        service = new SongService();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String saveSong(Song obj) {
        service.saveSong(obj);
        return "Song has been saved";
    }

    @GET
    public List<Song> getAllSongs() {
        return service.getAllSongs();
    }
    @GET
    @Path("/{songid}")
    public Song getSong(@PathParam("songid") int songid) {
        return service.getSong(songid);
    }


    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public String updateSong(Song obj) {
        service.updateSong(obj);
        return "Song has been updated";
    }

    @DELETE
    @Path("/{songid}")
    public String deleteSong(@PathParam("songid") int songid) {
        service.deleteSong(songid);
        return "Song has been removed";
    }

    @GET
    @Path("/search")
    public List<Song> searchSongs(@QueryParam("title") String keyword,
//    							@QueryParam("title") String title,
                                  @QueryParam("genre") String genre,
                                  @QueryParam("mood") String mood,
                                  @QueryParam("lyrics") String lyrics) {
        return service.searchSongs(keyword, genre, mood, lyrics);
        
        
    }
}
