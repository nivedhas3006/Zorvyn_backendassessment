package com.example.demo.controller;
 
import java.util.List;

import com.example.demo.bean.Artist;
import com.example.demo.service.ArtistService;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.MediaType;
 
@Path("/dbartist")
public class ArtistController {
    private ArtistService service;
 
    public ArtistController() {
        service = new ArtistService();
    }
 
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String saveArtist(Artist obj) {
        service.saveArtist(obj);
        return "Artist has been saved";
    }
 
    @GET
    public List<Artist> getAllArtists() {
        return service.getAllArtists();
    }
 
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public String updateArtist(Artist obj) {
        service.updateArtist(obj);
        return "Artist has been updated";
    }
 
    @DELETE
    @Path("/{id}")
    public String deleteArtist(@PathParam("id") int id) {
        service.deleteArtist(id);
        return "Artist has been removed";
    }
 
    @GET
    @Path("/{id}")
    public Artist getArtist(@PathParam("id") int id) {
        return service.getArtist(id);
    }
}