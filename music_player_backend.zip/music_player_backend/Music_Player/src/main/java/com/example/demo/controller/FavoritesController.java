package com.example.demo.controller;
 
import java.util.List;

import com.example.demo.bean.Favorites;
import com.example.demo.service.FavoritesService;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.MediaType;
 
@Path("/dbfavorites")
public class FavoritesController {
    private FavoritesService service;
 
    public FavoritesController() {
        service = new FavoritesService();
    }
 
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String saveFavorites(Favorites fav) {
        service.saveFavorites(fav);
        return "Favorites has been saved";
    }
 
    @GET
    public List<Favorites> getAllFavorites() {
        return service.getAllFavorites();
    }
 
    @GET
    @Path("/{id}")
    public Favorites getFavorites(@PathParam("id") int id) {
        return service.getFavorites(id);
    }
 
    @DELETE
    @Path("/{id}")
    public String deleteFavorites(@PathParam("id") int id) {
        service.deleteFavorites(id);
        return "Favorites has been removed";
    }
}