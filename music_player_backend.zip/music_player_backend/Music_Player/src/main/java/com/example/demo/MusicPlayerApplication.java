package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicPlayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicPlayerApplication.class, args);
	}

}













//http://localhost:8080/dbuser (POST create)  
//http://localhost:8080/dbuser (GET all)  
//http://localhost:8080/dbuser/{id} (GET one)  
//http://localhost:8080/dbuser (PUT update)  
//http://localhost:8080/dbuser/{id} (DELETE)  
//
//http://localhost:8080/dbsong (POST create)  
//http://localhost:8080/dbsong (GET all)  
//http://localhost:8080/dbsong/{id} (GET one)  
//http://localhost:8080/dbsong (PUT update)  
//http://localhost:8080/dbsong/{id} (DELETE)  
//
//http://localhost:8080/dbplaylist (POST create)  
//http://localhost:8080/dbplaylist (GET all)  
//http://localhost:8080/dbplaylist/{id} (GET one)  
//http://localhost:8080/dbplaylist (PUT update)  
//http://localhost:8080/dbplaylist/{id} (DELETE)  
//
//http://localhost:8080/dbartist (POST create)  
//http://localhost:8080/dbartist (GET all)  
//http://localhost:8080/dbartist/{id} (GET one)  
//http://localhost:8080/dbartist (PUT update)  
//http://localhost:8080/dbartist/{id} (DELETE)  
//
//http://localhost:8080/dbfavorites (POST create)  
//http://localhost:8080/dbfavorites (GET all)  
//http://localhost:8080/dbfavorites/{id} (GET one)  
//http://localhost:8080/dbfavorites/{id} (DELETE)  


//GET http://localhost:8080/dbsong/search?title=Perfect


//{
//	  "userid": 4,
//	  "name": "David",
//	  "email": "david@example.com",
//	  "password": "david123"
//	}
//{
//	  "playlistId": 4,
//	  "name": "Romantic Hits",
//	  "userId": 4
//	}
//{
//	  "artistId": 5,
//	  "name": "Taylor Swift",
//	  "genre": "Pop",
//	  "followers": 4000000,
//	  "totalListeners": 15000000
//	}
//{
//	  "songid": 5,
//	  "title": "Shape of You",
//	  "genre": "Pop",
//	  "mood": "Happy",
//	  "lyrics": "The club isn't the best place...",
//	  "artistId": 1
//	}
