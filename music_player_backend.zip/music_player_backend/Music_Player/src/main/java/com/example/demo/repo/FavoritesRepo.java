package com.example.demo.repo;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.bean.Favorites;
import com.example.demo.config.Config;
 
public class FavoritesRepo {
 
    public void saveFavorites(Favorites fav) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO Favorites(user_id, song_id) VALUES(?,?)");
            ps.setInt(1, fav.getUserId());
            ps.setInt(2, fav.getSongId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public void deleteFavorites(int id) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement("DELETE FROM Favorites WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public List<Favorites> getAllFavorites() {
        List<Favorites> list = new ArrayList<>();
        try (Connection con = Config.getConnectionFormsql();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                 "SELECT f.id, f.user_id, f.song_id, s.title AS songName " +
                 "FROM Favorites f JOIN song s ON f.song_id = s.songid")) {
            while (rs.next()) {
                Favorites f = new Favorites();
                f.setId(rs.getInt("id"));
                f.setUserId(rs.getInt("user_id"));
                f.setSongId(rs.getInt("song_id"));
                f.setSongName(rs.getString("songName"));
                list.add(f);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
 
    public Favorites getFavorites(int id) {
        Favorites fav = null;
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "SELECT f.id, f.user_id, f.song_id, s.title AS songName " +
                "FROM Favorites f JOIN song s ON f.song_id = s.songid WHERE f.id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                fav = new Favorites();
                fav.setId(rs.getInt("id"));
                fav.setUserId(rs.getInt("user_id"));
                fav.setSongId(rs.getInt("song_id"));
                fav.setSongName(rs.getString("songName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fav;
    }
}