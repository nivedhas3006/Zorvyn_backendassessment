package com.example.demo.bean;
 
public class Artist {
    private int artistId;
    private String name;
    private String genre;
    private int followers;
    private int totalListeners;
 
    // Getters and Setters
    public int getArtistId() {
        return artistId;
    }
    public void setArtistId(int artistId) {
        this.artistId = artistId;
    }
 
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
 
    public String getGenre() {
        return genre;
    }
    public void setGenre(String genre) {
        this.genre = genre;
    }
 
    public int getFollowers() {
        return followers;
    }
    public void setFollowers(int followers) {
        this.followers = followers;
    }
 
    public int getTotalListeners() {
        return totalListeners;
    }
    public void setTotalListeners(int totalListeners) {
        this.totalListeners = totalListeners;
    }
}
 
