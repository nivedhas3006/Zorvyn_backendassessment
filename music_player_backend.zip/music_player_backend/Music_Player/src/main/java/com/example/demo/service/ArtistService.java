
package com.example.demo.service;
 
import java.util.List;

import com.example.demo.bean.Artist;
import com.example.demo.repo.ArtistRepo;
 
public class ArtistService {
    private ArtistRepo repo;
 
    public ArtistService() {
        repo = new ArtistRepo();
    }
 
    public void saveArtist(Artist obj) {
        repo.saveArtist(obj);
    }
 
    public List<Artist> getAllArtists() {
        return repo.getAllArtists();
    }
 
    public void updateArtist(Artist obj) {
        repo.updateArtist(obj);
    }
 
    public void deleteArtist(int id) {
        repo.deleteArtist(id);
    }
 
    public Artist getArtist(int id) {
        return repo.getArtist(id);
    }
}