package com.example.demo.repo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.bean.Playlist;
import com.example.demo.bean.Song;
import com.example.demo.config.Config;

public class PlaylistRepo {

    public void savePlaylist(Playlist playlist) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO playlist(name, user_id) VALUES(?, ?)");
            ps.setString(1, playlist.getName());
            ps.setInt(2, playlist.getUserId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Playlist> getAllPlaylists() {
        List<Playlist> list = new ArrayList<>();
        try (Connection con = Config.getConnectionFormsql();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM playlist")) {
            while (rs.next()) {
                Playlist p = new Playlist();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setUserId(rs.getInt("user_id"));
                list.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void updatePlaylist(Playlist playlist) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE playlist SET name=?, user_id=? WHERE id=?");
            ps.setString(1, playlist.getName());
            ps.setInt(2, playlist.getUserId());
            ps.setInt(3, playlist.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePlaylist(int id) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps1 = con.prepareStatement("DELETE FROM playlist_song WHERE playlistId=?");
            ps1.setInt(1, id);
            ps1.executeUpdate();
            PreparedStatement ps2 = con.prepareStatement("DELETE FROM playlist WHERE id=?");
            ps2.setInt(1, id);
            ps2.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Playlist getPlaylist(int id) {
        Playlist p = null;
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM playlist WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                p = new Playlist();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setUserId(rs.getInt("user_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }

    public void addSongToPlaylist(int playlistId, int songId) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO playlist_song(playlistId, songId) VALUES(?, ?)");
            ps.setInt(1, playlistId);
            ps.setInt(2, songId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Song> getSongsByPlaylist(int playlistId) {
        List<Song> list = new ArrayList<>();
        try (Connection con = Config.getConnectionFormsql();
             PreparedStatement ps = con.prepareStatement(
                 "SELECT s.* FROM song s JOIN playlist_song ps ON s.songid = ps.songId WHERE ps.playlistId=?")) {
            ps.setInt(1, playlistId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Song s = new Song();
                s.setSongid(rs.getInt("songid"));
                s.setTitle(rs.getString("title"));
                s.setArtist(rs.getString("artist"));
                s.setGenre(rs.getString("genre"));
                s.setMood(rs.getString("mood"));
                s.setLyrics(rs.getString("lyrics"));
                list.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public void removeSongFromPlaylist(int playlistId, int songId) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "DELETE FROM playlist_song WHERE playlistId=? AND songId=?");
            ps.setInt(1, playlistId);
            ps.setInt(2, songId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
