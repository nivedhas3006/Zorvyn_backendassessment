package com.example.demo.controller;

import java.util.List;

import com.example.demo.bean.User;
import com.example.demo.service.UserService;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.MediaType;

@Path("/dbuser")
public class UserController {
    private UserService service;

    public UserController() {
        service = new UserService();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String saveUser(User obj) {
        service.saveUser(obj);
        return "User has been saved";
    }

    @GET
    public List<User> getAllUsers() {
        return service.getAllUsers();
    }
    
    @GET
    @Path("/{userid}")
    public User getUser(@PathParam("userid") int userid) {
        return service.getUser(userid);
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public String updateUser(User obj) {
        service.updateUser(obj);
        return "User has been updated";
    }

    @DELETE
    @Path("/{userid}")
    public String deleteUser(@PathParam("userid") int userid) {
        service.deleteUser(userid);
        return "User has been removed";
    }
}
