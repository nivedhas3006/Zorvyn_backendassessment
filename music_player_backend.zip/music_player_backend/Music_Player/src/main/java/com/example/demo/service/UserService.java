package com.example.demo.service;
 
import java.util.List;

import com.example.demo.bean.User;
import com.example.demo.repo.UserRepo;
 
public class UserService {
    private UserRepo repo;
 
    public UserService() {
        repo = new UserRepo();
    }
 
    public void saveUser(User obj) {
        repo.saveUser(obj);
    }
 
    public List<User> getAllUsers() {
        return repo.getAllUsers();
    }
 
    public void updateUser(User obj) {
        repo.updateUser(obj);
    }
 
    public void deleteUser(int userid) {
        repo.deleteUser(userid);
    }
 
    public User getUser(int userid) {
        return repo.getUser(userid);
    }
}
 