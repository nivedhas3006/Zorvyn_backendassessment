package com.example.demo.bean;

public class Playlist {
    private int id;
    private String name;
    private int userId;
//    private int songId;

    // Getter and Setter for id
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    // Getter and Setter for name
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for userId
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }

//    // Getter and Setter for songId
//    public int getSongId() {
//        return songId;
//    }
//    public void setSongId(int songId) {
//        this.songId = songId;
//    }
}
