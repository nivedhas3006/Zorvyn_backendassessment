package com.example.demo.repo;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.bean.User;
import com.example.demo.config.Config;
 
public class UserRepo {
 
    public void saveUser(User user) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO users(name,email,premimum) VALUES(?,?,?)");
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getUseremail());
            ps.setBoolean(3, user.isPremimum());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        try (Connection con = Config.getConnectionFormsql();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM users")) {
            while (rs.next()) {
                User u = new User();
                u.setUserid(rs.getInt("userid"));
                u.setUsername(rs.getString("name"));
                u.setUseremail(rs.getString("email"));
                u.setPremimum(rs.getBoolean("premimum"));
                list.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
 
    // Update user
    public void updateUser(User user) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE users SET name=?, email=?, premimum=? WHERE userid=?");
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getUseremail());
            ps.setBoolean(3, user.isPremimum());
            ps.setInt(4, user.getUserid());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    // Delete user
    public void deleteUser(int userid) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement("DELETE FROM users WHERE userid=?");
            ps.setInt(1, userid);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    // Get single user by ID
    public User getUser(int userid) {
        User u = null;
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE userid=?");
            ps.setInt(1, userid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                u = new User();
                u.setUserid(rs.getInt("userid"));
                u.setUsername(rs.getString("name"));
                u.setUseremail(rs.getString("email"));
                u.setPremimum(rs.getBoolean("premimum"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return u;
    }
}
