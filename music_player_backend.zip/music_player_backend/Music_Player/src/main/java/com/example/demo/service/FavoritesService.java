package com.example.demo.service;
 
import java.util.List;

import com.example.demo.bean.Favorites;
import com.example.demo.repo.FavoritesRepo;
 
public class FavoritesService {
    private FavoritesRepo repo;
 
    public FavoritesService() {
        repo = new FavoritesRepo();
    }
 
    public void saveFavorites(Favorites fav) {
        repo.saveFavorites(fav);
    }
 
    public void deleteFavorites(int id) {
        repo.deleteFavorites(id);
    }
 
    public List<Favorites> getAllFavorites() {
        return repo.getAllFavorites();
    }
 
    public Favorites getFavorites(int id) {
        return repo.getFavorites(id);
    }
}