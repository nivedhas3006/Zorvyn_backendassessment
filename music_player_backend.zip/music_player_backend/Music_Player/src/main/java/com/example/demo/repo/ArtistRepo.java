
package com.example.demo.repo;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.bean.Artist;
import com.example.demo.config.Config;
 
public class ArtistRepo {
 
    public void saveArtist(Artist artist) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO artist(name, genre, followers, total_listeners) VALUES(?,?,?,?)");
            ps.setString(1, artist.getName());
            ps.setString(2, artist.getGenre());
            ps.setInt(3, artist.getFollowers());
            ps.setInt(4, artist.getTotalListeners());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public List<Artist> getAllArtists() {
        List<Artist> list = new ArrayList<>();
        try (Connection con = Config.getConnectionFormsql();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM artist")) {
            while (rs.next()) {
                Artist a = new Artist();
                a.setArtistId(rs.getInt("artist_id"));
                a.setName(rs.getString("name"));
                a.setGenre(rs.getString("genre"));
                a.setFollowers(rs.getInt("followers"));
                a.setTotalListeners(rs.getInt("total_listeners"));
                list.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
 
    public void updateArtist(Artist artist) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE artist SET name=?, genre=?, followers=?, total_listeners=? WHERE artist_id=?");
            ps.setString(1, artist.getName());
            ps.setString(2, artist.getGenre());
            ps.setInt(3, artist.getFollowers());
            ps.setInt(4, artist.getTotalListeners());
            ps.setInt(5, artist.getArtistId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public void deleteArtist(int id) {
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement("DELETE FROM artist WHERE artist_id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public Artist getArtist(int id) {
        Artist a = null;
        try (Connection con = Config.getConnectionFormsql()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM artist WHERE artist_id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                a = new Artist();
                a.setArtistId(rs.getInt("artist_id"));
                a.setName(rs.getString("name"));
                a.setGenre(rs.getString("genre"));
                a.setFollowers(rs.getInt("followers"));
                a.setTotalListeners(rs.getInt("total_listeners"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return a;
    }
}
