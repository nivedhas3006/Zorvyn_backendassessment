package com.example.demo.bean;

public class Song {
private int songid;
private String title;
private String artist;
private String genre;
private String mood;
private String lyrics;
public int getSongid() {
	return songid;
}
public void setSongid(int songid) {
	this.songid = songid;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getArtist() {
	return artist;
}
public void setArtist(String artist) {
	this.artist = artist;
}
public String getGenre() {
	return genre;
}
public void setGenre(String genre) {
	this.genre = genre;
}
public String getMood() {
	return mood;
}
public void setMood(String mood) {
	this.mood = mood;
}
public String getLyrics() {
	return lyrics;
}
public void setLyrics(String lyrics) {
	this.lyrics = lyrics;
}




}
