package com.example.demo.bean;
 
public class Favorites {
    private int id;
    private int userId;
    private int songId;
    private String songName; // optional field to hold song title
 
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
 
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
 
    public int getSongId() { return songId; }
    public void setSongId(int songId) { this.songId = songId; }
 
    public String getSongName() { return songName; }
    public void setSongName(String songName) { this.songName = songName; }
}